export const teamMembers = [
  { name: "김찬영", role: "VR 콘텐츠 제작" },
  { name: "박시은", role: "VR 콘텐츠 제작" },
  { name: "이유림", role: "VR 콘텐츠 제작" },
  { name: "김민성", role: "VR 콘텐츠 제작" },
  { name: "송지은", role: "VR 콘텐츠 제작" },
  { name: "신진하", role: "앱 기능 / 디자인" },
  { name: "오태관", role: "앱 기능 / 디자인" },
  { name: "구지현", role: "웹 기능 / 디자인" },
  { name: "김병권", role: "웹 기능 / 디자인" },
  { name: "노현길", role: "총괄 / DB통신" },
  { name: "김형중", role: "감정 분석 / DB통신" }
];
