export const newsUpdates = [
  {
    yearMonth: "2025.07",
    items: [
      {
        date: "2025.07.20",
        version: "v0.5",
        content: "EmotionVR 0.5 베타버전 출시!"
      },
      {
        date: "2025.07.10",
        version: "",
        content: "웹 기능 작업 및 UI 디자인 개선"
      },
      {
        date: "2025.05.20",
        version: "",
        content: "감정 분석 기능 연동 및 테스트 완료"
      },
      {
        date: "2025.05.01",
        version: "",
        content: "EmotionVR 프로젝트 개발 시작"
      }
    ]
  }
];