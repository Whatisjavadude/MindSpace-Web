import Main_Page from "./pages/Main_Page";

function App() {
  return (
   <Main_Page />
  );
}

export default App;
